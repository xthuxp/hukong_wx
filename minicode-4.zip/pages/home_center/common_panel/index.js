// miniprogram/pages/home_center/common_panel/index.js.js
import {
  getDevFunctions,
  getDeviceDetails,
  deviceControl,
  getDevicetotal,
  getDevicejinrileiji,
  getDeviceList
} from '../../../utils/api/device-api'
import wxMqtt from '../../../utils/mqtt/wxMqtt'

let {
  dcOn,
  dcOff,
  power,
  powerOff,
  schedule,
  statistics,
  timer,
  bgImage
} = require('./img')


Page({


  /**
   * 页面的初始数据
   */
  data: {
    multiArray: [
      ['电动车', '手机'],
      ['5', '10', '20', '50', '100'],
      ['5分钟', '30分钟']
    ],
    objectMultiArray: [
      [{
          id: 0,
          name: '电动车'
        },
        {
          id: 1,
          name: '手机'
        }
      ],
      [{
          id: 0,
          name: '5'
        },
        {
          id: 1,
          name: '10'
        },
        {
          id: 2,
          name: '20'
        },
        {
          id: 3,
          name: '50'
        },
        {
          id: 3,
          name: '100'
        }
      ],
      [{
          id: 0,
          name: '5分钟'
        },
        {
          id: 1,
          name: '30分钟'
        }
      ]
    ],
    multiIndex: [0, 0, 0],
    devicekey: '',
    bagin: '',
    benci: '',
    countDownNum: '',
    ele: '',
    thisDay: '',
    lishidianliang: '',
    time: '3',
    statusCount: 0,
    current: 0,
    loading: true,
    device_name: '',
    titleItem: {
      name: '',
      value: '',
    },
    roDpList: {}, //只上报功能点
    rwDpList: {}, //可上报可下发功能点
    isRoDpListShow: false,
    isRwDpListShow: false,
    imgList: {
      dcOn,
      dcOff,
      power,
      powerOff,
      schedule,
      statistics,
      timer,
      bgImage
    }
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    const {
      device_id
    } = options
    this.setData({
      device_id
    })

    // mqtt消息监听
    wxMqtt.on('message', (topic, newVal) => {
      const {
        status
      } = newVal
      console.log("newVal", newVal)
      this.updateStatus(status)
    })

  },

  onShow: async function () {

    
    

    let that = this
    let bagin = that.data.bagin
    const {
      device_id
    } = that.data
    //获取电量
    const ele = await getDevicetotal(device_id)
    that.setData({
      ele: ele.total
    })
    //获取今日、累计电量
    const jinrileiji = await getDevicejinrileiji(device_id)
    that.setData({
      thisDay: jinrileiji.thisDay
    })
    that.setData({
      lishidianliang: jinrileiji.sum
    })

    let now = jinrileiji.sum
    var benci = now - bagin
    console.log('benci', benci)


    that.setData({
      benci: benci.toFixed(2)
    })
  },
  /*
    onShow: function () {
      let that = this
      let now=that.data.lishidianliang
      that.setData({
        benci :now-that.bagin
      }
      )

    },*/

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: async function () {

    const {
      device_id
    } = this.data
    const [{
      name,
      status,
      icon
    }, {
      functions = []
    }] = await Promise.all([
      getDeviceDetails(device_id),
      getDevFunctions(device_id),

    ]);
    this.setData({
      loading: false
    })

    //获得上传下发list
    const {
      roDpList,
      rwDpList
    } = this.reducerDpList(status, functions)

    // 获取头部展示功能点信息
    let titleItem = {
      name: '',
      value: '',
    };
    if (Object.keys(roDpList).length > 0) {
      let keys = Object.keys(roDpList)[0];
      titleItem = roDpList[keys];
    } else {
      let keys = Object.keys(rwDpList)[0];
      titleItem = rwDpList[keys];
    }

    const roDpListLength = Object.keys(roDpList).length
    const isRoDpListShow = Object.keys(roDpList).length > 0
    const isRwDpListShow = Object.keys(rwDpList).length > 0

    this.setData({
      titleItem,
      roDpList,
      rwDpList,
      device_name: name,
      isRoDpListShow,
      isRwDpListShow,
      roDpListLength,
      icon
    })
    console.log('switch', rwDpList['switch']['value'])

    const params = {
      // name 云函数的名称，必须使用 ty-service
      name: "ty-service",
      data: {
        //"action": "statistics.total",
        "action": "timer.list",
        "params": {
          "device_id": device_id,
          /*"loops":"0000000",
          "category":"test",
          "timezone_id":"Asia/Shanghai",
          "time_zone":"+8:00",
          "instruct":[
            {
                "functions":[
                    {
                        "code":"switch",
                        "value":true
                    },
                ],
                "date":"20210429",
                "time":"21:15"
            }
        ]

*/
        }
      }
    };

    wx.cloud.callFunction(params).then(res => {
      console.log('res', res); // 打印出来的结果可以看到获取的设备功能点
    }).catch(err => console.log('err', err))


  },

  // 分离只上报功能点，可上报可下发功能点
  reducerDpList: function (status, functions) {
    // 处理功能点和状态的数据
    let roDpList = {};
    let rwDpList = {};
    if (status && status.length) {
      status.map((item) => {
        const {
          code,
          value
        } = item;
        let isExit = functions.find(element => element.code == code);
        if (isExit) {
          let rightvalue = value
          // 兼容初始拿到的布尔类型的值为字符串类型
          if (isExit.type === 'Boolean') {
            rightvalue = value == 'true'
          }
          rwDpList[code] = {
            code,
            value: rightvalue,
            type: isExit.type,
            values: isExit.values,
            name: isExit.name,
          };
        } else {
          roDpList[code] = {
            code,
            value,
            name: code,
          };
        }
      });
    }
    return {
      roDpList,
      rwDpList
    }
  },

  sendDp: function (dpCode, value) {
    const {
      device_id
    } = this.data
    deviceControl(device_id, dpCode, value)
  },

  updateStatus: function (newStatus) {
    let {
      roDpList,
      rwDpList,
      titleItem
    } = this.data
    

    newStatus.forEach(item => {
      const {
        code,
        value
      } = item

      if (typeof roDpList[code] !== 'undefined') {
        roDpList[code]['value'] = value;
      } else if (rwDpList[code]) {
        rwDpList[code]['value'] = value;
      }
    })

    // 更新titleItem
    if (Object.keys(roDpList).length > 0) {
      let keys = Object.keys(roDpList)[0];
      titleItem = roDpList[keys];
    } else {
      let keys = Object.keys(rwDpList)[0];
      titleItem = rwDpList[keys];
    }

    this.setData({
      titleItem,
      roDpList: {
        ...roDpList
      },
      rwDpList: {
        ...rwDpList
      }
    })
  },

  jumpTodeviceEditPage: function () {

    const {
      icon,
      device_id,
      device_name
    } = this.data
    wx.navigateTo({
      url: `/pages/home_center/device_manage/index?device_id=${device_id}&device_name=${device_name}&device_icon=${icon}`,
    })
  },

  //定时跳转
  dianliangtj: function () {
    wx.navigateTo({
      url: '/pages/home_center/common_panel/settime/settime',
    })
  },

  settime: function () {

    wx.navigateTo({
      url: '/pages/home_center/common_panel/dingshi/dinghsi',
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
    var time = this.data.multiArray[2]
    console.log('time', time)
  },
  bindMultiPickerColumnChange: function (e) {
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    switch (e.detail.column) {
      case 0:
        switch (data.multiIndex[0]) {
          case 0:
            data.multiArray[1] = ['5', '10', '20', '50', '100'];
            data.multiArray[2] = ['5分钟', '30分钟'];
            break;
          case 1:
            data.multiArray[1] = ['5', '10', '20', '50', '100'];
            data.multiArray[2] = ['5分钟', '30分钟'];
            break;
        }
        data.multiIndex[1] = 0;
        data.multiIndex[2] = 0;
        break;
    }
    console.log(data.multiIndex);
    this.setData(data);
  },

  //时间选择countDown
  bindTimeChange: function (e) {
    let that = this;

    console.log('picker发送选择改变，携带值为', e.detail.value)
    let time = e.detail.value;
    console.log('h1', time[0])
    console.log('h2', time[1])
    console.log('h3', time[3])
    console.log('h4', time[4])

    let h1 = time[0]
    let h2 = time[1]
    let m1 = time[3]
    let m2 = time[4]

    let s = h1 * 36000 + h2 * 3600 + m1 * 600 + m2 * 60
    console.log('t', s)

    that.setData({
      countDownNum: s
    })

    that.sendDp('countdown_1', s)
  },
  //countDown
  smart: function () {
    //获取倒计时的变量
    var time = this.data.multiArray[2][multiIndex[2]]
    console.log('time', time)
    /*const countDown = setInterval(() => {
      if(time==0){
        this.setData({
          sendMessage: "重新发送",
          disabled:""
        })
        //清除定时器
        clearInterval(countDown);
      }else{
        time--;
        this.setData({
          sendMessage: time + "s",
          disabled:"disabled"
        })
      }
    }, 1000)*/
  },


  shuaxin: async function () {
    const deviceList = await getDeviceList()
    console.log('deviceList', deviceList[1].status[0].value)
    this.setData({
      devicekey: deviceList[1].status[0].value
    })
  },

  //改变设备状态
  turnDeviceOn: function (e) {
    let that = this
    let bagin = that.data.lishidianliang
    console.log('onoff')
    const {
      value
    } = that.data.rwDpList.switch;
    that.sendDp('switch', !value)
   
    
    that.setData({
      bagin: bagin
    })
    console.log('bagin', bagin)

  }

})