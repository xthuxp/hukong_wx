// pages/home_center/common_panel/components/settime.js
import {
  getDevice7dayele
} from '../../../../utils/api/device-api'

let utils = require('../../../../utils/utils'); //应用模块
let Charts = require('../../../../utils/wxcharts.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: {},

    date: '2021-05-04',
    device_id: '327508562cf43233d451',
    sdayele: {},
    today: '',
    linex: [],
    liney: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    

    //修改顶部文字
    wx.setNavigationBarTitle({
      title: '更多电量信息'
    })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: async function () {


    //获取今7天电量
    var date = utils.formatDate(new Date());
    this.setData({
      today: date
    })
    console.log("today", this.data.today)
    var dateLast = utils.getTimeLastWeek(new Date()); //前7天时间
    console.log("当前时间：", date, dateLast);
    const sdayele = await getDevice7dayele("327508562cf43233d451", dateLast, date)
    console.log("sdayele", sdayele)
    let sevendayele = sdayele.days
    console.log("7dayele", sevendayele)
    this.setData({
      sdayele: sevendayele
    })


    var windowWidth = 320;
    try {
      var res = wx.getSystemInfoSync();
      windowWidth = res.windowWidth;
    } catch (e) {
      console.error('getSystemInfoSync failed!');
    }

    //日期
    let obj = this.data.sdayele
    let linex = this.data.linex
    let liney = this.data.liney
    for (var key in obj) {
      linex.push(key);
      liney.push(obj[key]);
      console.log("liney", liney);
    }
    this.setData({
      linex: linex,
      liney: liney
    })

    //图表
    new Charts({

      canvasId: 'canvas1',
      type: 'line',

      categories: this.data.linex,
      series: [{
        name: '近日用电量',
        data: this.data.liney,
        format: function (val) {
          return val + '千瓦时';
        }
      }],
      yAxis: {
        format: function (val) {
          return val + '度';
        }
      },
      width: windowWidth,
      height: 200,
      dataPointShape: true,
      extra: {
        lineStyle: 'straight'
      }
    });



  },
  bindDateChangeB: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    let y_m_d = e.detail.value
    let ymd = y_m_d[0] + y_m_d[1] + y_m_d[2] + y_m_d[3] + y_m_d[5] + y_m_d[6] + y_m_d[8] + y_m_d[9]
    this.setData({
      dateB: ymd
    })
  },
  bindDateChangeE: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    let y_m_d2 = e.detail.value
    let ymd2 = y_m_d2[0] + y_m_d2[1] + y_m_d2[2] + y_m_d2[3] + y_m_d2[5] + y_m_d2[6] + y_m_d2[8] + y_m_d2[9]
    this.setData({
      dateE: ymd2
    })
  },
  chaxun: async function (e) {
    let dateB = this.data.dateB
    let dateE = this.data.dateE
    const ele = await getDevice7dayele("327508562cf43233d451", dateB, dateE)
    console.log("ele", ele)
    this.setData({
      list: ele.days,
      sdayele: ele.days
    })
    var windowWidth = 320;
    try {
      var res = wx.getSystemInfoSync();
      windowWidth = res.windowWidth;
    } catch (e) {
      console.error('getSystemInfoSync failed!');
    }
    //日期
    let obj = this.data.sdayele
    let linex = this.data.linex
    let liney = this.data.liney
    linex=[]
    liney=[]
    for (var key in obj) {
      linex.push(key);
      liney.push(obj[key]);
      console.log("liney", liney);
    }
    this.setData({
      linex: linex,
      liney: liney
    })

    //图表
    new Charts({

      canvasId: 'canvas1',
      type: 'line',
      dataLabel: true,
      categories: this.data.linex,
      series: [{
        name: '近日用电量',
        data: this.data.liney,
        format: function (val) {
          return val ;
        }
      }],
      yAxis: {
        format: function (val) {
          return val + '度';
        }
      },
      width: windowWidth,
      height: 200
      
      
    });

    console.log("liste", this.data.list)
  }



})