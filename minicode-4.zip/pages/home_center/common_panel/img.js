const dcOn = '/image/dc102_1_on.png'
const dcOff = '/image/dc102_1_off.png'
const power = '/image/power_on.png'
const powerOff = '/image/power_off.png'
const schedule = '/image/schedule.png'
const statistics = '/image/statistics.png'
const timer = '/image/timer.png'
const bgImage = '/image/bg_2_q_on.png'

module.exports =  {
  dcOn,
  dcOff,
  power,
  powerOff,
  schedule,
  statistics,
  timer,
  bgImage
}