// pages/home_center/common_panel/components/dingshi/dinghsi.js





import {
  getDevicedingshiliebiao,
  getDeviceaddtimer,
  getDevicetimerdelete
} from '../../../../utils/api/device-api'
Page({

  /**
   * 页面的初始数据
   */
  data: {

    date: '2021-05-04',
    time: '12:01',

    array: ['ture', 'flase'],
    objectArray: [{
        id: 0,
        name: 'ture'
      },
      {
        id: 1,
        name: 'flase'
      }
    ],
    index: 0,

    list: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    //修改顶部文字
    wx.setNavigationBarTitle({
      title: '定时列表'
    })
    this.app = getApp();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: async function () {
    const liebiao = await getDevicedingshiliebiao("327508562cf43233d451")
    console.log("liebiao", liebiao)
    console.log("liebiao", liebiao[0].groups)
    this.setData({
      list: liebiao[0].groups
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   

   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  //你可以看到，动画参数的200,0与渐入时的-200,1刚好是相反的，其实也就做到了页面还原的作用，使页面重新打开时重新展示动画
  //this.app.show(this, 'slide_up1', 200, 0)
  //延时展现容器2，做到瀑布流的效果，见上面预览图
  
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },


  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  bindTimeChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time: e.detail.value
    })
  },
  fasong: async function () {
    let dingshi_kg = this.data.array[this.data.index]
    
    let y_m_d = this.data.date
    let ymd = y_m_d[0] + y_m_d[1] + y_m_d[2] + y_m_d[3] + y_m_d[5] + y_m_d[6] + y_m_d[8] + y_m_d[9]
    let hhmm = this.data.time

    const res = await getDeviceaddtimer("327508562cf43233d451", dingshi_kg, ymd, hhmm)
    console.log("res", res)
    wx.showToast({
      title: '设置成功',
      icon: '', //默认值是success,就算没有icon这个值，就算有其他值最终也显示success
      duration: 2000, //停留时间
    })

    const liebiao = await getDevicedingshiliebiao("327508562cf43233d451")
    console.log("liebiao", liebiao)
    console.log("liebiao", liebiao[0].groups)
    this.setData({
      list: liebiao[0].groups
    })
  },
  shanchu: function () {
    wx.showModal({
      title: '提示',
      content: '确认要删除所有定时吗？，删除后请推出页面重新进入查看。',
      success: function (res) {
        if (res.confirm) {
          getDevicetimerdelete("327508562cf43233d451")
          console.log('点击确认回调')
          wx.showToast({
            title: '删除成功',
            icon: '', //默认值是success,就算没有icon这个值，就算有其他值最终也显示success
            duration: 2000, //停留时间
          })
        } else {
          console.log('点击取消回调')
        }
      }
    })
  },
})